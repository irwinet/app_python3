from setuptools import setup 

setup(
    name="paquete",
    version="0.1",
    description="Este es un paquete de ejemplo",
    author="Irwinet",
    author_email="irwin@gmail.com",
    url="http://irwin.com",
    scripts=[],
    packages=["paquete","paquete.adios","paquete.hola"]
)

