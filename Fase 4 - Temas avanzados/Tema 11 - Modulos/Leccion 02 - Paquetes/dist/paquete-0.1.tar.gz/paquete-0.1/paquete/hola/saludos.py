# Este es un modulo con funciones que saludan

def saludar():
    print("Hola, te estoy salundo de la funcion saludar del modulo saludos")

class Saludo():
    def __init__(self):
        print("Hola te estoy salundado desde el init de la clase saludo")